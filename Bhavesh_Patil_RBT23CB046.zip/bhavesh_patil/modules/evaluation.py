import streamlit as st

def render_evaluation_form():
    st.markdown("Rate each quality dimension from **1 (very poor) to 5 (excellent)**.")
    with st.form("human_evaluation_form"):
        c1, c2, c3 = st.columns(3)
        with c1:
            accuracy = st.slider("Accuracy", 1, 5, 3,
                                 help="Are the claims factually correct?")
        with c2:
            relevance = st.slider("Relevance", 1, 5, 3,
                                  help="Does the response answer the question?")
        with c3:
            completeness = st.slider("Completeness", 1, 5, 3,
                                     help="Does it cover the important points?")
        hallucination = st.radio(
            "Did you identify a hallucination or unsupported factual claim?",
            ["No", "Yes"], horizontal=True
        )
        evidence = st.text_area(
            "Evidence / problematic sentence (especially if hallucination = Yes)",
            placeholder="Paste the claim, explain why it is incorrect, or provide a supporting source..."
        )
        feedback = st.text_area("Evaluator comments and suggestions",
                                placeholder="What was good? What should be improved?")
        corrected = st.text_area("Suggested corrected answer (optional)",
                                 placeholder="Enter a corrected answer if needed.")
        submitted = st.form_submit_button("Save evaluation", type="primary", use_container_width=True)
    if submitted:
        if hallucination == "Yes" and not evidence.strip():
            st.warning("Please identify the unsupported claim or explain the issue before saving.")
            return None
        return (
            {"accuracy": accuracy, "relevance": relevance, "completeness": completeness},
            hallucination, evidence.strip(), feedback.strip(), corrected.strip()
        )
    return None
