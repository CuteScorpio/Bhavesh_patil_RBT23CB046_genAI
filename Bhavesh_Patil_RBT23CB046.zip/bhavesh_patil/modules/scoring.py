def calculate_score(accuracy: int, relevance: int, completeness: int, hallucination: str) -> float:
    """
    Accuracy, relevance and completeness are rated 1-5.
    No hallucination = 5 points; Yes = 0 points.
    Total possible points = 20.
    """
    hallucination_points = 0 if hallucination == "Yes" else 5
    return ((accuracy + relevance + completeness + hallucination_points) / 20) * 100

def score_label(score: float) -> str:
    if score >= 90:
        return "Excellent"
    if score >= 75:
        return "Good"
    if score >= 50:
        return "Average"
    return "Needs improvement"
