from typing import Optional, List, Dict, Any
from google import genai

MODEL_MAP = {
    "3.8": "gemini-3.8-flash",
    "gemini-3.8": "gemini-3.8-flash",
    "gemini-3.8-flash": "gemini-3.8-flash",
    "gemini-3.5-flash-lite": "gemini-3.5-flash-lite",
    "gemini-3.1-pro-preview": "gemini-3.1-pro-preview",
    "gemini-2.5-flash": "gemini-2.5-flash",
    "gemini-2.5-flash-lite": "gemini-2.5-flash-lite",
    "gemini-2.0-flash": "gemini-2.0-flash",
    "gemini-2.0-flash-lite": "gemini-2.0-flash-lite",
    "gemini-1.5-flash": "gemini-1.5-flash",
    "gemini-1.5-pro": "gemini-1.5-pro",
}


def resolve_model_name(model_name: Optional[str]) -> str:
    """Normalize model identifier and resolve common shorthand aliases."""
    if not model_name:
        return "gemini-3.8-flash"
    cleaned = model_name.strip()
    return MODEL_MAP.get(cleaned, cleaned or "gemini-3.8-flash")


def diagnose_api_connection(api_key: str) -> Dict[str, Any]:
    """
    Test connectivity to the Google Gemini API using the provided key.
    Returns a dictionary with status, available models, and human-readable error messages.
    """
    cleaned_key = (api_key or "").strip()
    if not cleaned_key:
        return {
            "success": False,
            "error": "No API key provided. Please paste your Gemini API key in the settings sidebar.",
            "raw_error": None,
            "models": []
        }

    try:
        client = genai.Client(api_key=cleaned_key)
        available = []
        for m in client.models.list():
            model_id = getattr(m, "name", "") or ""
            if model_id.startswith("models/"):
                model_id = model_id[len("models/"):]
            supported = getattr(m, "supported_actions", []) or []
            if not supported or "generateContent" in supported:
                available.append(model_id)
        return {
            "success": True,
            "error": None,
            "raw_error": None,
            "models": available
        }
    except Exception as exc:
        err_msg = str(exc)
        if "API_KEY_INVALID" in err_msg or "400" in err_msg:
            friendly = "API key is invalid. Please copy a fresh Gemini API key from Google AI Studio (https://aistudio.google.com/)."
        elif "429" in err_msg or "RESOURCE_EXHAUSTED" in err_msg:
            friendly = "API rate limit or quota exceeded for this key. Please wait a moment or check your AI Studio quota."
        elif "PERMISSION_DENIED" in err_msg or "403" in err_msg:
            friendly = "Permission denied. Ensure your API key is enabled in Google AI Studio."
        else:
            friendly = f"Connection failed: {err_msg}"
        return {
            "success": False,
            "error": friendly,
            "raw_error": err_msg,
            "models": []
        }


def _try_interactions_api(client: genai.Client, model: str, prompt: str) -> Optional[str]:
    """Attempt generation via Interactions API."""
    try:
        interaction = client.interactions.create(
            model=model,
            input=prompt
        )
        text = getattr(interaction, "output_text", None)
        if not text and hasattr(interaction, "steps"):
            for step in reversed(interaction.steps):
                if getattr(step, "type", "") == "model_output":
                    for item in getattr(step, "content", []):
                        if getattr(item, "type", "") == "text":
                            val = getattr(item, "text", "")
                            if val:
                                text = val
                                break
                    if text:
                        break
        if text and text.strip():
            return text.strip()
    except Exception:
        pass
    return None


def _try_generate_content(client: genai.Client, model: str, prompt: str) -> Optional[str]:
    """Attempt generation via models.generate_content without unsupported parameters."""
    try:
        response = client.models.generate_content(
            model=model,
            contents=prompt
        )
        text = getattr(response, "text", None)
        if text and text.strip():
            return text.strip()
        # Fallback to candidate parts
        if hasattr(response, "candidates") and response.candidates:
            first = response.candidates[0]
            if hasattr(first, "content") and hasattr(first.content, "parts"):
                parts_text = "".join(getattr(p, "text", "") for p in first.content.parts if getattr(p, "text", None))
                if parts_text.strip():
                    return parts_text.strip()
    except Exception:
        pass
    return None


def generate_response(question: str, api_key: str, model_name: str = "gemini-3.8-flash") -> str:
    """
    Generate an answer using Google Gemini API.
    Attempts primary model first (Interactions API / generate_content),
    then gracefully tries fallback models if the model is not found on this account.
    """
    cleaned_key = (api_key or "").strip()
    if not cleaned_key:
        raise ValueError("A valid Gemini API key is required. Please provide it in the settings sidebar.")

    cleaned_question = (question or "").strip()
    if not cleaned_question:
        raise ValueError("The prompt/question cannot be empty.")

    target_model = resolve_model_name(model_name)
    client = genai.Client(api_key=cleaned_key)
    prompt = (
        "Answer the user's question clearly and accurately. "
        "If you are uncertain, say so rather than inventing facts.\n\n"
        f"Question: {cleaned_question}"
    )

    # Build candidate model list with prioritized fallbacks
    candidate_models: List[str] = [target_model]
    for fb in ["gemini-3.8-flash", "gemini-2.5-flash", "gemini-2.0-flash", "gemini-1.5-flash"]:
        if fb not in candidate_models:
            candidate_models.append(fb)

    last_error: Optional[Exception] = None

    for m in candidate_models:
        # For Gemini 3.x, prioritize Interactions API then generate_content
        if "gemini-3" in m:
            text = _try_interactions_api(client, m, prompt)
            if text:
                return text
            text = _try_generate_content(client, m, prompt)
            if text:
                return text
        else:
            # For Gemini 2.x or 1.x, prioritize generate_content
            text = _try_generate_content(client, m, prompt)
            if text:
                return text
            text = _try_interactions_api(client, m, prompt)
            if text:
                return text

    # If all silent attempts failed, make one direct call to capture the explicit exception
    try:
        client.models.generate_content(model=target_model, contents=prompt)
    except Exception as exc:
        last_error = exc

    err_str = str(last_error) if last_error else "Model returned an empty response."
    if "API_KEY_INVALID" in err_str:
        raise RuntimeError("Your Gemini API key is invalid. Please verify and re-enter your key from Google AI Studio.")
    elif "429" in err_str or "RESOURCE_EXHAUSTED" in err_str:
        raise RuntimeError("Gemini API quota/rate limit exceeded. Please wait a moment or check your AI Studio quota.")
    elif "404" in err_str or "NOT_FOUND" in err_str:
        raise RuntimeError(f"Model '{target_model}' was not found for this API key. Try testing connection in the sidebar.")
    elif last_error:
        raise RuntimeError(f"Gemini API error ({type(last_error).__name__}): {err_str}")

    raise RuntimeError("The model returned an empty response. Please try asking again.")
