import streamlit as st
import pandas as pd
import plotly.express as px

def render_dashboard(df: pd.DataFrame):
    st.subheader("Evaluation analytics")
    if df.empty or len(df) == 0:
        st.info("Save some evaluations to see dashboard analytics.")
        return

    total = len(df)
    avg_score = float(df["overall_score"].mean()) if "overall_score" in df else 0.0
    hallucination_rate = float((df["hallucination"] == "Yes").mean() * 100) if "hallucination" in df else 0.0
    avg_accuracy = float(df["accuracy"].mean()) if "accuracy" in df else 0.0

    a, b, c, d = st.columns(4)
    a.metric("Total evaluations", total)
    b.metric("Average quality score", f"{avg_score:.1f}%")
    c.metric("Hallucination rate", f"{hallucination_rate:.1f}%")
    d.metric("Average accuracy", f"{avg_accuracy:.2f}/5")

    st.divider()
    left, right = st.columns(2)
    with left:
        metric_df = pd.DataFrame({
            "Metric": ["Accuracy", "Relevance", "Completeness"],
            "Average rating": [
                df["accuracy"].mean() if "accuracy" in df else 0.0,
                df["relevance"].mean() if "relevance" in df else 0.0,
                df["completeness"].mean() if "completeness" in df else 0.0
            ]
        })
        fig = px.bar(metric_df, x="Metric", y="Average rating", range_y=[0, 5],
                     title="Average human ratings")
        st.plotly_chart(fig, use_container_width=True)
    with right:
        if "hallucination" in df:
            hall_df = df["hallucination"].value_counts().rename_axis("Hallucination").reset_index(name="Count")
            fig = px.pie(hall_df, names="Hallucination", values="Count",
                         title="Hallucination detection",
                         color="Hallucination",
                         color_discrete_map={"Yes": "#EF553B", "No": "#00CC96"})
            st.plotly_chart(fig, use_container_width=True)

    if "overall_score" in df:
        score_fig = px.histogram(df, x="overall_score", nbins=10,
                                 title="Distribution of overall quality scores",
                                 labels={"overall_score": "Quality score (%)"})
        st.plotly_chart(score_fig, use_container_width=True)

    st.caption("Scores reflect the submitted human ratings and the project's scoring formula; they are not an objective guarantee of model quality.")
