import sqlite3
from contextlib import contextmanager
from pathlib import Path
import pandas as pd

DB_PATH = Path(__file__).resolve().parent / "evaluations.db"

COLUMNS = [
    "id", "created_at", "evaluator", "question", "response",
    "accuracy", "relevance", "completeness", "hallucination",
    "evidence", "feedback", "corrected_answer", "overall_score"
]


@contextmanager
def get_connection():
    """Context manager providing a safe, automatically committed and closed SQLite connection."""
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db():
    """Initialize database table if it doesn't already exist."""
    with get_connection() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS evaluations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                evaluator TEXT NOT NULL,
                question TEXT NOT NULL,
                response TEXT NOT NULL,
                accuracy INTEGER NOT NULL CHECK(accuracy BETWEEN 1 AND 5),
                relevance INTEGER NOT NULL CHECK(relevance BETWEEN 1 AND 5),
                completeness INTEGER NOT NULL CHECK(completeness BETWEEN 1 AND 5),
                hallucination TEXT NOT NULL CHECK(hallucination IN ('Yes','No')),
                evidence TEXT,
                feedback TEXT,
                corrected_answer TEXT,
                overall_score REAL NOT NULL
            )
        """)


def save_evaluation(**data):
    """Save an evaluation record to the database."""
    fields = ["evaluator", "question", "response", "accuracy", "relevance",
              "completeness", "hallucination", "evidence", "feedback",
              "corrected_answer", "overall_score"]
    values = [data.get(field) for field in fields]
    with get_connection() as conn:
        cur = conn.execute(
            f"INSERT INTO evaluations ({','.join(fields)}) VALUES ({','.join(['?']*len(fields))})",
            values
        )
        return cur.lastrowid


def get_evaluations() -> pd.DataFrame:
    """Retrieve all evaluation records ordered newest to oldest."""
    with get_connection() as conn:
        rows = conn.execute("SELECT * FROM evaluations ORDER BY id DESC").fetchall()
    if not rows:
        return pd.DataFrame(columns=COLUMNS)
    return pd.DataFrame([dict(row) for row in rows])


def delete_evaluation(evaluation_id: int) -> bool:
    """Delete an evaluation record by ID."""
    with get_connection() as conn:
        cur = conn.execute("DELETE FROM evaluations WHERE id = ?", (evaluation_id,))
        return cur.rowcount > 0
