# Human-in-the-Loop AI Evaluation System

A Streamlit application for human evaluators to assess AI-generated responses for:
- Accuracy
- Relevance
- Completeness
- Hallucinations / unsupported claims

It also stores evaluations in SQLite and provides a dashboard and CSV export.

## 1. Requirements

- Python 3.10 or newer
- Internet connection for Gemini response generation (powered by Gemini 3.8 Flash)
- Gemini API key (optional if you enter AI responses manually)

## 2. Setup in VS Code

Open this project folder in VS Code. Open the terminal in the project folder and run:

### Windows

```powershell
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```

If PowerShell blocks activation, use Command Prompt:

```cmd
.venv\Scripts\activate.bat
pip install -r requirements.txt
streamlit run app.py
```

### macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

The application opens in your browser, usually at `http://localhost:8501`.

## 3. Gemini API key & Models

1. Open Google AI Studio: https://aistudio.google.com/
2. Create or copy a Gemini API key.
3. Paste it into the **Gemini API key** field in the app sidebar (or set `GEMINI_API_KEY` in your environment).
4. The default model is **Gemini 3.8 Flash** (`gemini-3.8-flash`), optimized for fast, accurate responses.
5. Enter a question and click **Generate with Gemini**.

Keep your API key private. Do not commit it to GitHub or share it in screenshots.

You can use the manual response option without an API key.

## 4. How to use

1. Enter a question in **Generate response**.
2. Generate a response with Gemini, or paste a response manually.
3. Open **Evaluate response**.
4. Rate accuracy, relevance and completeness from 1 to 5.
5. Mark whether a hallucination or unsupported claim was found.
6. If you select Yes, identify the claim or explain the evidence.
7. Add optional feedback and a corrected answer.
8. Click **Save evaluation**.
9. Open **Dashboard** to review metrics and charts.
10. Open **Evaluation history** to inspect or export records.

## 5. Scoring formula

The project uses a simple illustrative score:

`Score = (Accuracy + Relevance + Completeness + Hallucination points) / 20 * 100`

- Each of the first three ratings is from 1 to 5.
- No hallucination = 5 points.
- Hallucination detected = 0 points.

This is a project-defined scoring rule, not a universal evaluation standard. A hallucination flag should be based on evidence, not merely a difference in wording from a reference answer.

Suggested labels:
- 90–100: Excellent
- 75–89: Good
- 50–74: Average
- Below 50: Needs improvement

## 6. Project structure

```text
HITL_AI_Evaluation/
├── app.py
├── requirements.txt
├── README.md
├── modules/
│   ├── ai_generator.py
│   ├── evaluation.py
│   ├── scoring.py
│   └── dashboard.py
├── database/
│   └── db.py
└── data/
    └── sample_evaluations.csv
```

The SQLite database file is created automatically the first time the application runs.

## 7. Sample test cases

Use the included `data/sample_evaluations.csv` to understand the kinds of examples you can evaluate. The CSV is a reference dataset; the app does not automatically import it.

## 8. Limitations and future improvements

- The current version uses one evaluator name per submission; it does not yet implement user accounts or reviewer authentication.
- Human ratings are subjective. For stronger research, use multiple independent evaluators and compare agreement.
- The hallucination field records the evaluator's judgement; it does not independently prove a claim is false.
- Future improvements can include reference-document upload, sentence-level claim highlighting, multi-evaluator agreement, role-based login, and automated evaluation comparisons.
