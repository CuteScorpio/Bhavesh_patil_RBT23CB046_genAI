import os
from pathlib import Path
import streamlit as st
import pandas as pd
from modules.ai_generator import generate_response, diagnose_api_connection
from modules.scoring import calculate_score, score_label
from modules.evaluation import render_evaluation_form
from modules.dashboard import render_dashboard
from database.db import init_db, save_evaluation, get_evaluations, delete_evaluation

st.set_page_config(page_title="HITL AI Evaluation", page_icon="🧑‍⚖️", layout="wide")
init_db()

st.title("🧑‍⚖️ Human-in-the-Loop AI Evaluation")
st.caption("Evaluate AI-generated responses for accuracy, relevance, completeness, and hallucinations.")

with st.sidebar:
    st.header("⚙️ Settings")
    st.markdown("**Gemini API key**")
    default_key = os.environ.get("GEMINI_API_KEY", "")
    api_key = st.text_input(
        "Enter your Gemini API key",
        value=default_key,
        type="password",
        help="Get an API key from Google AI Studio (https://aistudio.google.com/). It is used only for response generation."
    )
    
    available_model_options = [
        "gemini-3.8-flash",
        "gemini-2.5-flash",
        "gemini-2.0-flash",
        "gemini-1.5-flash",
        "gemini-3.5-flash-lite",
        "gemini-3.1-pro-preview"
    ]
    model_name = st.selectbox(
        "Gemini model",
        available_model_options,
        index=0,
        help="Default is gemini-3.8-flash (fast, accurate, latest Gemini 3 model)."
    )
    
    if st.button("🔌 Test API Connection & Models", use_container_width=True):
        cleaned_key = api_key.strip() if api_key else ""
        if not cleaned_key:
            st.error("Please enter an API key above first.")
        else:
            with st.spinner("Connecting to Google Gemini API..."):
                diag = diagnose_api_connection(cleaned_key)
                if diag["success"]:
                    st.success("✅ Connected successfully to Google Gemini API!")
                    if diag["models"]:
                        st.markdown(f"**Available models on this key ({len(diag['models'])}):**")
                        gemini_models = [m for m in diag["models"] if "gemini" in m.lower()][:10]
                        st.write(", ".join(f"`{m}`" for m in (gemini_models or diag["models"][:8])))
                else:
                    st.error(f"❌ {diag['error']}")
                    if diag.get("raw_error"):
                        with st.expander("Show raw error"):
                            st.code(diag["raw_error"], language="text")

    evaluator = st.text_input("Evaluator name / ID", value="Evaluator 1")
    st.divider()
    st.info("You can also paste an AI response manually if you do not have an API key.")

tab_generate, tab_evaluate, tab_dashboard, tab_history = st.tabs(
    ["✨ Generate response", "📝 Evaluate response", "📊 Dashboard", "📚 Evaluation history"]
)

if "question" not in st.session_state:
    st.session_state.question = ""
if "ai_response" not in st.session_state:
    st.session_state.ai_response = ""

with tab_generate:
    st.subheader("Generate an AI response")
    
    cleaned_api_key = api_key.strip() if api_key else ""
    if not cleaned_api_key:
        st.warning("⚠️ **Gemini API key is not set.** Please enter your Gemini API key in the sidebar under Settings, or use the manual response form below.")

    question = st.text_area(
        "Enter the question or prompt",
        key="question_input",
        placeholder="Example: Explain artificial intelligence in simple words.",
        height=110
    )
    col1, col2 = st.columns([1, 1])
    with col1:
        if st.button("Generate with Gemini", type="primary", use_container_width=True):
            if not question.strip():
                st.warning("Please enter a question first.")
            elif not cleaned_api_key:
                st.error("Enter your Gemini API key in the sidebar, or use manual response entry below.")
            else:
                with st.spinner(f"Generating response with {model_name}..."):
                    try:
                        answer = generate_response(question, cleaned_api_key, model_name)
                        st.session_state.question = question.strip()
                        st.session_state.ai_response = answer
                        st.success("Response generated! Open the 'Evaluate response' tab.")
                    except Exception as exc:
                        st.error(f"Could not generate response: {exc}")
                        with st.expander("🛠️ Debug Details & Troubleshooting"):
                            st.markdown(f"**Model requested**: `{model_name}`")
                            st.markdown(f"**Error summary**: `{str(exc)}`")
                            st.markdown(
                                """
                                **Next steps to resolve**:
                                1. **Test your key**: Click **'🔌 Test API Connection & Models'** in the sidebar.
                                2. **Check your key**: Make sure you created a key at [Google AI Studio](https://aistudio.google.com/).
                                3. **Try another model**: Select `gemini-2.5-flash` or `gemini-2.0-flash` from the dropdown if 3.8 is not yet provisioned on your project.
                                4. **Manual test**: You can also use the 'Or enter a response manually' box below.
                                """
                            )
    with col2:
        if st.button("Clear generated response", use_container_width=True):
            st.session_state.question = ""
            st.session_state.ai_response = ""
            if "question_input" in st.session_state:
                st.session_state.question_input = ""
            st.rerun()

    st.divider()
    st.subheader("Or enter a response manually")
    manual_question = st.text_area("Question", key="manual_question", height=75)
    manual_answer = st.text_area("AI-generated response", key="manual_answer", height=150)
    col_m1, col_m2 = st.columns([1, 1])
    with col_m1:
        if st.button("Use manual response", use_container_width=True):
            if manual_question.strip() and manual_answer.strip():
                st.session_state.question = manual_question.strip()
                st.session_state.ai_response = manual_answer.strip()
                st.success("Response loaded. Open the 'Evaluate response' tab.")
            else:
                st.warning("Enter both a question and a response.")
    with col_m2:
        # Load sample data if available
        sample_path = Path(__file__).resolve().parent / "data" / "sample_evaluations.csv"
        if sample_path.exists():
            if st.button("Load sample test case", use_container_width=True):
                try:
                    samples_df = pd.read_csv(sample_path)
                    if not samples_df.empty:
                        sample_row = samples_df.iloc[0]
                        st.session_state.question = str(sample_row["question"])
                        st.session_state.ai_response = str(sample_row["ai_response"])
                        st.success(f"Sample test case loaded ('{sample_row['question'][:40]}...'). Open the 'Evaluate response' tab.")
                except Exception as e:
                    st.warning(f"Could not load sample data: {e}")

    if st.session_state.ai_response:
        st.markdown("**Current response preview**")
        st.info(st.session_state.ai_response)

with tab_evaluate:
    st.subheader("Human evaluation")
    if "last_saved_message" in st.session_state and st.session_state.last_saved_message:
        st.success(st.session_state.last_saved_message)
        del st.session_state.last_saved_message

    if not st.session_state.question or not st.session_state.ai_response:
        st.info("Generate a response or enter one manually in the 'Generate response' tab.")
    else:
        st.markdown("**Question**")
        st.write(st.session_state.question)
        st.markdown("**AI response**")
        st.info(st.session_state.ai_response)
        result = render_evaluation_form()
        if result:
            ratings, hallucination, evidence, feedback, corrected = result
            score = calculate_score(ratings["accuracy"], ratings["relevance"],
                                    ratings["completeness"], hallucination)
            saved_id = save_evaluation(
                evaluator=evaluator.strip() or "Anonymous",
                question=st.session_state.question,
                response=st.session_state.ai_response,
                accuracy=ratings["accuracy"],
                relevance=ratings["relevance"],
                completeness=ratings["completeness"],
                hallucination=hallucination,
                evidence=evidence,
                feedback=feedback,
                corrected_answer=corrected,
                overall_score=score
            )
            msg = f"Evaluation #{saved_id} saved successfully! Score: {score:.1f}% — {score_label(score)}"
            st.session_state.last_saved_message = msg
            st.toast(msg, icon="✅")
            st.session_state.question = ""
            st.session_state.ai_response = ""
            if "question_input" in st.session_state:
                st.session_state.question_input = ""
            st.rerun()

with tab_dashboard:
    render_dashboard(get_evaluations())

with tab_history:
    st.subheader("Saved evaluations")
    history = get_evaluations()
    if history.empty:
        st.info("No evaluations saved yet.")
    else:
        display_cols = ["id", "created_at", "evaluator", "question", "accuracy",
                        "relevance", "completeness", "hallucination", "overall_score"]
        available_cols = [c for c in display_cols if c in history.columns]
        st.dataframe(history[available_cols], use_container_width=True, hide_index=True)
        csv = history.to_csv(index=False).encode("utf-8")
        st.download_button("⬇️ Download all evaluations (CSV)", csv,
                           "hitl_evaluations.csv", "text/csv")
        st.divider()
        selected_id = st.number_input("Evaluation ID to delete", min_value=1, step=1)
        if st.button("Delete selected evaluation"):
            if delete_evaluation(int(selected_id)):
                st.toast(f"Evaluation #{selected_id} deleted.", icon="🗑️")
                st.rerun()
            else:
                st.warning("No evaluation found with that ID.")
